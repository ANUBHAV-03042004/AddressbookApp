package com.addressbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressbookAppApplicationTests {

    @Test
    void contextLoads() {
    }
}
